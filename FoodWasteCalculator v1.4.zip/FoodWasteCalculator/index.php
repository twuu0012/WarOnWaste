<?php

/*
Plugin Name: Food Waste Calculator
Plugin URI: https://www.winningthewaronwaste.tk
Description: ShortCode [Food-Waste-Calculator]
Version: 1.4
Author: Tony Wu
License: A "Slug" license name e.g. GPL2
*/

// User cannot access the plugin directly
if (!defined('ABSPATH')) {
    exit;
}

// Add short code for the plugin
function short_code() {
    include 'food-waste-calculator.php';
}

add_shortcode('Food-Waste-Calculator', 'short_code');

// Add the scripts
function add_all_scripts() {

    wp_enqueue_script('calculator_script', plugins_url('/js/calculator_script.js',__FILE__), array(),'1.3',true);
    wp_enqueue_style( 'calculator_style', plugins_url('/css/calculator_style.css', __FILE__), array(), '1.3');
}

add_action('wp_enqueue_scripts', 'add_all_scripts');
